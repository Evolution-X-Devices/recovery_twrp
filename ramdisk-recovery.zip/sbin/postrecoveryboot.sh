
umount $ANDROID_ROOT
rm -f /system
